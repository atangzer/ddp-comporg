Hello! This is the readme file for Anna's (TANG ANNA YONGQI, 3180300155) MIPS assembler.

This folder should contain the following items:
	-assembler.py
	-test1.asm (Sample code to be assembled)
	-test2.asm (Contains disassembled MIPS of test2.hex)
	-test1.hex (Contains assembled machine language of test1.asm)
	-test2.hex (Sample code to be disassembled)
	-test1.coe (Contains assembled machine language of test1.asm)
	-test2.coe (Sample code to be disassembled)
	-TangAnna_AssemblerReport.pdf
	-readme.txt

To run the program, please open up command line and cd to the correct directory. Then, type python assembler.py into the command line.
Afterwards, please follow the program prompts. Make sure that the input files are in your current directory.

Make sure to read the report as well.

谢谢! :)
